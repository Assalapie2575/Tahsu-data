import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';

void main() {
  runApp(const TahsuDataApp());
}

class TahsuDataApp extends StatelessWidget {
  const TahsuDataApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TAHSU DATA',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Poppins',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5A00FF)),
      ),
      home: const SplashScreen(),
    );
  }
}
