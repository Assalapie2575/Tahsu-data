import 'package:flutter/material.dart';
import 'home_screen.dart';

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Account')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const Text('Let’s get you started',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          const SizedBox(height: 24),
          for (final item in ['Full Name', 'Phone Number', 'Password', 'Confirm Password'])
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: TextField(
                obscureText: item.toLowerCase().contains('password'),
                keyboardType: item == 'Phone Number'
                    ? TextInputType.phone
                    : TextInputType.text,
                decoration: InputDecoration(
                  labelText: item,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              ),
            ),
          FilledButton(
            onPressed: () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const HomeScreen()),
            ),
            child: const Padding(
              padding: EdgeInsets.all(14),
              child: Text('Register'),
            ),
          ),
        ],
      ),
    );
  }
}
